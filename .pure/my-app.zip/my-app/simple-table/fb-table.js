// fb-table.js  (UTF-8)
// Component: <fb-table> – nhận JSON qua attribute: columns, data; bật/tắt checkbox; optional simple-datatables
// - attributes: columns, data, checkbox, row-key, datatable
// - datatable: "", "true", or JSON options -> bật simple-datatables; "false"/null -> tắt
// - Public API: getSelected()

class FBTable extends HTMLElement {
    static get observedAttributes() { return ['columns','data','checkbox','row-key','datatable']; }

    constructor(){
        super();
        this._mounted = false;
        this._columns = [];   // [{ key, label, type, className? }]
        this._data = [];      // [{ ... , checked?: boolean }]
        this._checkbox = true;
        this._rowKey = 'id';

        // sort state (chỉ dùng khi KHÔNG bật datatable)
        this._sort = null; // { idx: number, dir: 'asc'|'desc' }

        // datatable
        this._useDataTable = false;
        this._dtOpts = {};
        this._dt = null;

        // map id -> index để sync selection ổn định (kể cả sort/paging phía frontend)
        this._idIndex = new Map();

        // helper để re-sync header khi datatable đổi trang/sort/search
        this._syncSelectionHeader = () => {};
    }

    // ===== Robust parsers for attribute JSON =====
    _parseJSONOrNull(s){ try { return JSON.parse(s); } catch { return null; } }
    _parseAttrJSON(raw){
        if (!raw) return null;
        const v = raw.trim();

        // 1) JSON thô
        let parsed = this._parseJSONOrNull(v);
        if (parsed) return parsed;

        // 2) URI-encoded
        try {
            const dec = decodeURIComponent(v);
            parsed = this._parseJSONOrNull(dec);
            if (parsed) return parsed;
        } catch {}

        // 3) base64 (cho phép prefix "base64,")
        try {
            const b64 = v.startsWith('base64,') ? v.slice(7) : v;
            const txt = atob(b64);
            parsed = this._parseJSONOrNull(txt);
            if (parsed) return parsed;
        } catch {}

        console.warn('[fb-table] Cannot parse JSON from attribute:', raw);
        return null;
    }

    // ===== lifecycle =====
    attributeChangedCallback(name, oldV, newV){
        if (oldV === newV) return;
        switch(name){
            case 'columns': {
                const v = this._parseAttrJSON(newV);
                if (Array.isArray(v)) this._columns = v;
                this._render();
                break;
            }
            case 'data': {
                const v = this._parseAttrJSON(newV);
                if (Array.isArray(v)) this._data = v;
                this._render();
                break;
            }
            case 'checkbox': {
                this._checkbox = !(newV === 'false' || newV === '0' || newV === 'off');
                this._render();
                break;
            }
            case 'row-key': {
                this._rowKey = newV || 'id';
                this._render();
                break;
            }
            case 'datatable': {
                if (newV === null || newV === 'false' || newV === '0' || newV === 'off'){
                    this._useDataTable = false;
                    this._dtOpts = {};
                } else {
                    const opt = this._parseAttrJSON(newV);
                    this._useDataTable = true;
                    this._dtOpts = opt && typeof opt === 'object' ? opt : {};
                }
                this._render();
                break;
            }
        }
    }

    get columns(){ return this._columns; }
    set columns(v){ this._columns = Array.isArray(v) ? v : []; this._render(); }

    get data(){ return this._data; }
    set data(v){ this._data = Array.isArray(v) ? v : []; this._render(); }

    get checkbox(){ return this._checkbox; }
    set checkbox(v){ this._checkbox = !!v; this._render(); }

    get rowKey(){ return this._rowKey; }
    set rowKey(v){ this._rowKey = v || 'id'; this._render(); }

    connectedCallback(){
        if (this._mounted) return;
        this._mounted = true;

        // Lấy state ban đầu từ attributes (nếu có)
        if (this.hasAttribute('columns')) {
            const v = this._parseAttrJSON(this.getAttribute('columns'));
            if (Array.isArray(v)) this._columns = v;
        }
        if (this.hasAttribute('data')) {
            const v = this._parseAttrJSON(this.getAttribute('data'));
            if (Array.isArray(v)) this._data = v;
        }
        if (this.hasAttribute('checkbox')) {
            const a = this.getAttribute('checkbox');
            this._checkbox = !(a === 'false' || a === '0' || a === 'off');
        }
        if (this.hasAttribute('row-key')) {
            this._rowKey = this.getAttribute('row-key') || 'id';
        }
        if (this.hasAttribute('datatable')) {
            const a = this.getAttribute('datatable');
            if (a === null || a === 'false' || a === '0' || a === 'off'){
                this._useDataTable = false;
            } else {
                const opt = this._parseAttrJSON(a);
                this._useDataTable = true;
                this._dtOpts = opt && typeof opt === 'object' ? opt : {};
            }
        }

        // Fallback: nếu thiếu columns thì dựng tối thiểu
        if (!this._columns.length) {
            this._columns = [
                { key:'no',        label:'No',            type:'number'   },
                { key:'region',    label:'Region',        type:'string'   },
                { key:'currentCpu',label:'Using CPU',     type:'string'   },
                { key:'recCpu',    label:'Recommended',   type:'string'   },
                { key:'saving',    label:'Saving',        type:'currency' },
                { key:'status',    label:'Status',        type:'string'   },
                { key:'desc',      label:'Description',   type:'string'   },
            ];
        }

        this._render();
    }

    // ===== render =====
    _render(){
        if (!this._mounted) return;

        // Hủy DT trước khi thay DOM
        if (this._dt && typeof this._dt.destroy === 'function') {
            this._dt.destroy();
            this._dt = null;
        }

        // rebuild id index map
        this._idIndex.clear();
        for (let i = 0; i < this._data.length; i++){
            const id = this._data[i]?.[this._rowKey];
            if (id !== undefined) this._idIndex.set(String(id), i);
        }

        const headerCells = this._columns.map((c, idx) => {
            const active = !this._useDataTable && this._sort && this._sort.idx === idx;
            const order  = active ? this._sort.dir : 'none';
            const aria   = active ? (order === 'asc' ? 'ascending' : 'descending') : 'none';
            return `
        <th class="px-4 py-3 cursor-pointer select-none"
            data-sortable="true"
            data-type="${c.type || 'string'}"
            data-col-idx="${idx}"
            data-order="${order}"
            aria-sort="${aria}">
          <div class="flex items-center gap-1">
            ${this._escape(c.label)}
            ${this._sortIcon(order)}
          </div>
        </th>
      `;
        }).join('');

        const thead = `
      <thead class="text-xs uppercase bg-gray-50">
        <tr>
          ${this._checkbox ? `
            <th class="px-4 py-3 w-10">
              <input id="checkbox-all" type="checkbox" class="cb" aria-label="Select all rows">
            </th>
          ` : ``}
          ${headerCells}
        </tr>
      </thead>`;

        const tbody = `
      <tbody class="divide-y divide-gray-100">
        ${this._data.map((row, i) => `
          <tr class="hover:bg-gray-50" data-row-index="${i}" data-row-id="${this._escape(row[this._rowKey])}">
            ${this._checkbox ? `
              <td class="px-4 py-4">
                <input type="checkbox" class="cb row-check" ${row.checked ? 'checked' : ''} aria-label="Select row">
              </td>` : ``}
            ${this._columns.map(c => `
              <td class="px-4 py-4 ${c.className || ''}">
                ${this._escape(row[c.key] ?? '')}
              </td>
            `).join('')}
          </tr>
        `).join('')}
      </tbody>`;

        this.innerHTML = `
      <div class="relative overflow-x-auto shadow-sm rounded-xl bg-white">
        <table class="w-full text-sm text-left text-gray-700">
          ${thead}${tbody}
        </table>
      </div>`;

        this._bind();

        // Khởi tạo DataTable nếu bật
        if (this._useDataTable) this._setupDataTable();
    }

    // ===== interactions =====
    _bind(){
        const table = this.querySelector('table');
        const tbody = table.tBodies[0];

        // === Sort thủ công: CHỈ dùng khi KHÔNG bật DataTable
        if (!this._useDataTable){
            const headers = table.querySelectorAll('th[data-sortable="true"]');
            const toComparable = (val, type) => {
                if (type === 'number' || type === 'currency'){
                    const n = parseFloat(String(val).replace(/[^0-9.-]/g,''));
                    return isNaN(n) ? -Infinity : n;
                }
                return String(val).toLowerCase();
            };

            headers.forEach(th => {
                th.addEventListener('click', () => {
                    const colIdx = Number(th.dataset.colIdx);
                    const type   = th.dataset.type || 'string';

                    // toggle 2 chiều
                    const current = (this._sort && this._sort.idx === colIdx) ? this._sort.dir : 'none';
                    const next    = current === 'asc' ? 'desc' : 'asc';
                    this._sort    = { idx: colIdx, dir: next };

                    const key = this._columns[colIdx].key;
                    this._data.sort((a,b) => {
                        const av = toComparable(a[key], type);
                        const bv = toComparable(b[key], type);
                        if (av < bv) return next === 'asc' ? -1 : 1;
                        if (av > bv) return next === 'asc' ?  1 : -1;
                        return 0;
                    });

                    this._render(); // re-render áp lại aria-sort/data-order
                });
            });
        }

        // === Checkbox logic (+ delegation để chịu DOM thay đổi khi dùng DataTable)
        if (this._checkbox){
            const checkboxAll = this.querySelector('#checkbox-all');
            const rowChecks = () => Array.from(this.querySelectorAll('tbody .row-check'));

            const syncMaster = () => {
                const rows = rowChecks();
                const checked = rows.filter(cb => cb.checked).length;
                if (checkboxAll){
                    checkboxAll.indeterminate = checked > 0 && checked < rows.length;
                    checkboxAll.checked = checked === rows.length && rows.length > 0;
                }
                // cập nhật _data theo row-id (ổn định với sort/paging)
                rows.forEach(cb => {
                    const tr = cb.closest('tr');
                    const rowId = tr?.dataset?.rowId;
                    if (rowId && this._idIndex.has(rowId)) {
                        const idx = this._idIndex.get(rowId);
                        this._data[idx].checked = cb.checked;
                    }
                });
                this.dispatchEvent(new CustomEvent('selectionchange', {
                    bubbles: true,
                    detail: {
                        selected: this.getSelected().map(x => x[this._rowKey]),
                        count: this.getSelected().length,
                        all: checkboxAll?.checked ?? false,
                        indeterminate: checkboxAll?.indeterminate ?? false
                    }
                }));
            };

            this._syncSelectionHeader = () => {
                // Khi datatable thay đổi DOM (paging/sort/search), đảm bảo checkbox reflects this._data
                const rows = rowChecks();
                rows.forEach(cb => {
                    const tr = cb.closest('tr');
                    const id = tr?.dataset?.rowId;
                    if (id && this._idIndex.has(id)) {
                        const idx = this._idIndex.get(id);
                        cb.checked = !!this._data[idx].checked;
                    }
                });
                // rồi đồng bộ master
                const checked = rows.filter(cb => cb.checked).length;
                if (checkboxAll){
                    checkboxAll.indeterminate = checked > 0 && checked < rows.length;
                    checkboxAll.checked = checked === rows.length && rows.length > 0;
                }
            };

            // Master change
            checkboxAll?.addEventListener('change', () => {
                const rows = rowChecks();
                rows.forEach(cb => { cb.checked = checkboxAll.checked; });
                syncMaster();
            });

            // Delegation cho row checkbox
            this.addEventListener('change', (e) => {
                const t = e.target;
                if (!(t instanceof HTMLInputElement)) return;
                if (t.matches('.row-check')) syncMaster();
                if (t.id === 'checkbox-all'){
                    const rows = rowChecks();
                    rows.forEach(cb => { cb.checked = t.checked; });
                    syncMaster();
                }
            }, true);

            // init
            this._syncSelectionHeader();
        }
    }

    _setupDataTable(){
        const table = this.querySelector('table');
        if (!window.simpleDatatables || !simpleDatatables.DataTable) {
            console.warn('[fb-table] simple-datatables not loaded');
            return;
        }
        this._dt = new simpleDatatables.DataTable(table, {
            perPage: 10,
            perPageSelect: [10,25,50,100],
            searchable: true,
            fixedHeight: false,
            ...this._dtOpts
        });

        const reSync = () => this._syncSelectionHeader();
        this._dt.on('datatable.page', reSync);
        this._dt.on('datatable.sort', reSync);
        this._dt.on('datatable.search', reSync);
        reSync();
    }

    // Public API
    getSelected(){ return this._data.filter(r => !!r.checked); }

    // Utils
    _escape(v){
        if (v === null || v === undefined) return '';
        return String(v)
            .replaceAll('&','&amp;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;')
            .replaceAll('"','&quot;')
            .replaceAll("'","&#39;");
    }

    _sortIcon(order){
        // inline SVG để khỏi lệ thuộc file ngoài
        const rotate = order === 'desc' ? 'rotate-180' : '';
        const active = order === 'none' ? 'opacity-30' : 'opacity-100';
        return `
      <svg class="w-3.5 h-3.5 ${active} ${rotate}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path d="M5.23 7.21a.75.75 0 01.53-.21h8.48a.75.75 0 01.53 1.28l-4.24 4.24a.75.75 0 01-1.06 0L5.23 8.28a.75.75 0 010-1.06z"/>
      </svg>`;
    }
}

if (!customElements.get('fb-table')) {
    customElements.define('fb-table', FBTable);
}
