// ih-tabs.js  (UTF-8)
// <ih-tabs> – Interactive Horizontal Tabs (pure Web Component, light DOM)
// Attributes:
//  - tabs        : JSON | URI-encoded | base64 (mảng [{label, content, html?}])
//  - active      : number (0-based)
//  - allow-html  : flag (bật render HTML trong content)
// Slot dạng <template data-tab="Label">...</template> cũng được hỗ trợ.
// Public API: el.active (get/set), el.tabs (get/set), 'change' event {detail:{index}}

(function(){
    const uid = () => 'ih-' + Math.random().toString(36).slice(2, 9);

    class IHTabs extends HTMLElement {
        static get observedAttributes(){ return ['tabs','active','allow-html']; }

        constructor(){
            super();
            this._mounted = false;
            this._id = uid();
            this._tabs = [
                { label: '서비스별(by service)', content: 'Service content would go here' },
                { label: '계정별(by account)',   content: 'Account content would go here' }
            ];
            this._active = 0;
            this._allowHtml = false;

            this.style.display = 'block'; // light DOM
        }

        // ---------- Utils ----------
        _parseJSONOrNull(s){ try { return JSON.parse(s); } catch { return null; } }
        _parseAttrJSON(raw){
            if (!raw) return null;
            const v = raw.trim();

            // JSON thô
            let p = this._parseJSONOrNull(v);
            if (p) return p;

            // URI-encoded
            try {
                const dec = decodeURIComponent(v);
                p = this._parseJSONOrNull(dec);
                if (p) return p;
            } catch {}

            // base64 (hỗ trợ prefix "base64,")
            try {
                const b64 = v.startsWith('base64,') ? v.slice(7) : v;
                const txt = atob(b64);
                p = this._parseJSONOrNull(txt);
                if (p) return p;
            } catch {}

            console.warn('[ih-tabs] cannot parse JSON:', raw);
            return null;
        }

        _escape(v){
            if (v === null || v === undefined) return '';
            return String(v)
                .replaceAll('&','&amp;')
                .replaceAll('<','&lt;')
                .replaceAll('>','&gt;')
                .replaceAll('"','&quot;')
                .replaceAll("'","&#39;");
        }

        _clampActive(){
            if (!this._tabs.length) { this._active = 0; return; }
            if (this._active < 0) this._active = 0;
            if (this._active > this._tabs.length - 1) this._active = this._tabs.length - 1;
        }

        _emitChange(){
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                detail: { index: this._active }
            }));
        }

        // ---------- Attributes ----------
        attributeChangedCallback(name, oldV, newV){
            if (oldV === newV) return;

            switch(name){
                case 'tabs': {
                    const v = this._parseAttrJSON(newV);
                    if (Array.isArray(v) && v.length){
                        this._tabs = v.map(x => ({
                            label: String(x.label ?? ''),
                            content: String(x.content ?? ''),
                            html: !!x.html
                        }));
                        // Nếu có tab nào html: true thì auto bật allow-html
                        if (this._tabs.some(t => t.html)) this._allowHtml = true;
                    }
                    this._clampActive();
                    this._render();
                    break;
                }
                case 'active': {
                    const n = Number(newV);
                    if (!Number.isNaN(n)) this._active = n;
                    this._clampActive();
                    this._reflectActive();
                    this._updatePanel();
                    break;
                }
                case 'allow-html': {
                    // attribute tồn tại và không phải 'false/0/off' → true
                    this._allowHtml = !(newV === null || newV === 'false' || newV === '0' || newV === 'off');
                    this._updatePanel();
                    break;
                }
            }
        }

        // ---------- Properties ----------
        get tabs(){ return this._tabs.slice(); }
        set tabs(v){
            if (Array.isArray(v) && v.length){
                this._tabs = v.map(x => ({
                    label: String(x.label ?? ''),
                    content: String(x.content ?? ''),
                    html: !!x.html
                }));
                if (this._tabs.some(t => t.html)) this._allowHtml = true;
                this._clampActive();
                this._render();
            }
        }

        get active(){ return this._active; }
        set active(i){
            const n = Number(i);
            if (!Number.isNaN(n)){
                this._active = n;
                this._clampActive();
                this._reflectActive();
                this._updatePanel();
                this._emitChange();
            }
        }

        // ---------- Lifecycle ----------
        connectedCallback(){
            if (this._mounted) return;
            this._mounted = true;

            // Ưu tiên <template data-tab="..."> nếu có
            const tpls = Array.from(this.querySelectorAll('template[data-tab]'));
            if (tpls.length){
                this._tabs = tpls.map(t => ({
                    label: String(t.dataset.tab || ''),
                    content: t.innerHTML, // lấy HTML của template
                    html: true
                }));
                this._allowHtml = true; // auto bật
            } else {
                // Đọc attributes nếu không có template
                if (this.hasAttribute('tabs')) {
                    const v = this._parseAttrJSON(this.getAttribute('tabs'));
                    if (Array.isArray(v) && v.length) {
                        this._tabs = v.map(x => ({
                            label: String(x.label ?? ''),
                            content: String(x.content ?? ''),
                            html: !!x.html
                        }));
                        if (this._tabs.some(t => t.html)) this._allowHtml = true;
                    }
                }
            }

            if (this.hasAttribute('active')) {
                const n = Number(this.getAttribute('active'));
                if (!Number.isNaN(n)) this._active = n;
            }

            if (this.hasAttribute('allow-html')) {
                const v = this.getAttribute('allow-html');
                this._allowHtml = !(v === 'false' || v === '0' || v === 'off');
            }

            this._clampActive();
            this._render();
        }

        // ---------- Render ----------
        _render(){
            if (!this._mounted) return;

            this.innerHTML = `
        <div class="ih-root w-full max-w-md">
          <style>
            /* Scoped .ih-* để chạy kể cả khi không có Tailwind */
            .ih-root { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; }
            .ih-h12   { height: 48px; }
            .ih-divider { position:absolute; left:0; right:0; bottom:0; height:1px; background:#e4e7ec; }
            .ih-tablist { position:absolute; left:0; top:0; display:flex; gap:16px; align-items:flex-start; }
            .ih-btn { display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; background:none; border:0; padding:0; }
            .ih-btn:focus-visible { outline: 2px solid #6941c6; outline-offset: 2px; border-radius: 6px; }
            .ih-label { padding: 0 4px 16px; font-weight: 600; font-size:14px; line-height:20px; color:#667085; white-space:nowrap; }
            .ih-label.active { color:#6941c6; }
            .ih-underline { height:2px; width:100%; background:transparent; }
            .ih-underline.active { background:#6941c6; }
            .ih-panel { margin-top:24px; padding:16px; background:#f9fafb; border-radius:8px; color:#374151; }
          </style>

          <div class="relative ih-h12">
            <div class="ih-divider"></div>
            <div class="ih-tablist" role="tablist" aria-label="Tabs"></div>
          </div>
          <div class="ih-panel" role="tabpanel" tabindex="0" id="${this._id}-panel"></div>
        </div>
      `;

            // Header buttons
            const list = this.querySelector('.ih-tablist');
            list.innerHTML = this._tabs.map((t, idx) => `
        <button
          type="button"
          class="ih-btn"
          role="tab"
          id="${this._id}-tab-${idx}"
          aria-controls="${this._id}-panel"
          aria-selected="${idx === this._active ? 'true' : 'false'}"
          tabindex="${idx === this._active ? '0' : '-1'}"
          data-idx="${idx}">
          <div class="ih-label ${idx === this._active ? 'active' : ''}">${this._escape(t.label)}</div>
          <div class="ih-underline ${idx === this._active ? 'active' : ''}"></div>
        </button>
      `).join('');

            // Content
            this._updatePanel();

            // Click
            list.querySelectorAll('.ih-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const i = Number(btn.dataset.idx);
                    if (!Number.isNaN(i)) this.active = i;
                });
            });

            // Keyboard nav (← → Home End)
            list.addEventListener('keydown', (e) => {
                const count = this._tabs.length;
                let next = this._active;
                if (e.key === 'ArrowRight') next = (this._active + 1) % count;
                else if (e.key === 'ArrowLeft') next = (this._active - 1 + count) % count;
                else if (e.key === 'Home') next = 0;
                else if (e.key === 'End') next = count - 1;
                else return;
                e.preventDefault();
                this.active = next;
                const nextBtn = this.querySelector(`#${this._id}-tab-${this._active}`);
                nextBtn?.focus();
            });
        }

        _updatePanel(){
            const panel = this.querySelector('.ih-panel');
            if (!panel) return;
            const t = this._tabs[this._active] || {};
            const htmlMode = this._allowHtml || !!t.html;
            if (htmlMode) {
                panel.innerHTML = t.content ?? '';
            } else {
                panel.textContent = t.content ?? '';
            }
            this._reflectActive();
        }

        _reflectActive(){
            this.querySelectorAll('.ih-btn').forEach(btn => {
                const idx = Number(btn.dataset.idx);
                const sel = idx === this._active;
                btn.setAttribute('aria-selected', sel ? 'true' : 'false');
                btn.setAttribute('tabindex', sel ? '0' : '-1');
                btn.querySelector('.ih-label')?.classList.toggle('active', sel);
                btn.querySelector('.ih-underline')?.classList.toggle('active', sel);
            });
            this.setAttribute('active', String(this._active));
        }
    }

    if (!customElements.get('ih-tabs')) {
        customElements.define('ih-tabs', IHTabs);
    }
})();
