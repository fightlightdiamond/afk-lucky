// fb-table.js  (UTF-8)
// Component: <fb-table> – nhận JSON qua attribute: columns, data; bật/tắt checkbox

class FBTable extends HTMLElement {
    static get observedAttributes() {
        return ['columns', 'data', 'checkbox', 'row-key'];
    }

    constructor() {
        super();
        this._mounted = false;
        this._columns = [];
        this._data = [];
        this._checkbox = true;
        this._rowKey = 'id';
        this._sort = null; // { idx: number, dir: 'asc'|'desc' }
    }


    // ===== Robust parsers for attribute JSON =====
    _parseJSONOrNull(s) {
        try {
            return JSON.parse(s);
        } catch {
            return null;
        }
    }

    _parseAttrJSON(raw) {
        if (!raw) return null;
        const v = raw.trim();

        // 1) thử JSON thô
        let parsed = this._parseJSONOrNull(v);
        if (parsed) return parsed;

        // 2) thử URI-encoded
        try {
            const dec = decodeURIComponent(v);
            parsed = this._parseJSONOrNull(dec);
            if (parsed) return parsed;
        } catch {
        }

        // 3) thử base64 (cho phép prefix "base64,")
        try {
            const b64 = v.startsWith('base64,') ? v.slice(7) : v;
            const txt = atob(b64);
            parsed = this._parseJSONOrNull(txt);
            if (parsed) return parsed;
        } catch {
        }

        console.warn('[fb-table] Cannot parse JSON from attribute:', raw);
        return null;
    }

    // ===== lifecycle =====
    attributeChangedCallback(name, oldV, newV) {
        if (oldV === newV) return;
        switch (name) {
            case 'columns': {
                const v = this._parseAttrJSON(newV);
                if (Array.isArray(v)) this._columns = v;
                this._render();
                break;
            }
            case 'data': {
                const v = this._parseAttrJSON(newV);
                if (Array.isArray(v)) this._data = v;
                this._render();
                break;
            }
            case 'checkbox': {
                this._checkbox = !(newV === 'false' || newV === '0' || newV === 'off');
                this._render();
                break;
            }
            case 'row-key': {
                this._rowKey = newV || 'id';
                break;
            }
        }
    }

    get columns() {
        return this._columns;
    }

    set columns(v) {
        this._columns = Array.isArray(v) ? v : [];
        this._render();
    }

    get data() {
        return this._data;
    }

    set data(v) {
        this._data = Array.isArray(v) ? v : [];
        this._render();
    }

    get checkbox() {
        return this._checkbox;
    }

    set checkbox(v) {
        this._checkbox = !!v;
        this._render();
    }

    get rowKey() {
        return this._rowKey;
    }

    set rowKey(v) {
        this._rowKey = v || 'id';
    }

    connectedCallback() {
        if (this._mounted) return;
        this._mounted = true;

        // Lấy state ban đầu từ attributes (nếu có)
        if (this.hasAttribute('columns')) {
            const v = this._parseAttrJSON(this.getAttribute('columns'));
            if (Array.isArray(v)) this._columns = v;
        }
        if (this.hasAttribute('data')) {
            const v = this._parseAttrJSON(this.getAttribute('data'));
            if (Array.isArray(v)) this._data = v;
        }
        if (this.hasAttribute('checkbox')) {
            const a = this.getAttribute('checkbox');
            this._checkbox = !(a === 'false' || a === '0' || a === 'off');
        }
        if (this.hasAttribute('row-key')) {
            this._rowKey = this.getAttribute('row-key') || 'id';
        }

        // Fallback: nếu thiếu columns thì dựng tối thiểu, tránh text non-ASCII
        if (!this._columns.length) {
            this._columns = [
                {key: 'no', label: 'No', type: 'number'},
                {key: 'region', label: 'Region', type: 'string'},
                {key: 'currentCpu', label: 'Using CPU', type: 'string'},
                {key: 'recCpu', label: 'Recommended', type: 'string'},
                {key: 'saving', label: 'Saving', type: 'currency'},
                {key: 'status', label: 'Status', type: 'string'},
                {key: 'desc', label: 'Description', type: 'string'},
            ];
        }

        this._render();
    }

    // ===== render =====
    _render() {
        if (!this._mounted) return;

        const thead = `
    <thead class="text-xs uppercase bg-gray-50">
      <tr>
        ${this._checkbox ? `
          <th class="px-4 py-3 w-10">
            <input id="checkbox-all" type="checkbox" class="cb" aria-label="Select all rows">
          </th>
        ` : ``}
        ${this._columns.map((c, idx) => {
            const active = this._sort && this._sort.idx === idx;
            const order = active ? this._sort.dir : 'none';
            const aria = active ? (order === 'asc' ? 'ascending' : 'descending') : 'none';
            return `
            <th class="px-4 py-3 cursor-pointer select-none"
                data-sortable="true"
                data-type="${c.type || 'string'}"
                data-col-idx="${idx}"
                data-order="${order}"
                aria-sort="${aria}">
              <div class="flex items-center gap-1">
                ${this._escape(c.label)}
                <img src="./selector.svg" class="sort-icon" alt="">
              </div>
            </th>
          `;
        }).join('')}
      </tr>
    </thead>`;

        const tbody = `
    <tbody class="divide-y divide-gray-100">
      ${this._data.map((row, i) => `
        <tr class="hover:bg-gray-50" data-row-index="${i}">
          ${this._checkbox ? `
            <td class="px-4 py-4">
              <input type="checkbox" class="cb row-check" ${row.checked ? 'checked' : ''} aria-label="Select row">
            </td>` : ``}
          ${this._columns.map(c => `
            <td class="px-4 py-4 ${c.className || ''}">
              ${this._escape(row[c.key] ?? '')}
            </td>
          `).join('')}
        </tr>
      `).join('')}
    </tbody>`;

        this.innerHTML = `
    <div class="relative overflow-x-auto shadow-sm rounded-xl bg-white">
      <table class="w-full text-sm text-left text-gray-700">
        ${thead}${tbody}
      </table>
    </div>`;

        this._bind();
    }


    // ===== interactions =====
    _bind(){
        const table = this.querySelector('table');
        const tbody = table.tBodies[0];

        const headers = table.querySelectorAll('th[data-sortable="true"]');
        const toComparable = (val, type) => {
            if (type === 'number' || type === 'currency'){
                const n = parseFloat(String(val).replace(/[^0-9.-]/g,''));
                return isNaN(n) ? -Infinity : n;
            }
            return String(val).toLowerCase();
        };

        headers.forEach(th => {
            th.addEventListener('click', () => {
                const colIdx = Number(th.dataset.colIdx);
                const type   = th.dataset.type || 'string';

                // xác định hướng mới dựa trên state hiện tại
                const current = (this._sort && this._sort.idx === colIdx) ? this._sort.dir : 'none';
                const next    = current === 'asc' ? 'desc' : 'asc';
                this._sort    = { idx: colIdx, dir: next };

                const key = this._columns[colIdx].key;
                this._data.sort((a,b) => {
                    const av = toComparable(a[key], type);
                    const bv = toComparable(b[key], type);
                    if (av < bv) return next === 'asc' ? -1 : 1;
                    if (av > bv) return next === 'asc' ?  1 : -1;
                    return 0;
                });

                this._render(); // re-render sẽ áp lại aria-sort/data-order từ this._sort
            });
        });

        // === Checkbox logic giữ nguyên như bạn ===
        if (this._checkbox){
            const checkboxAll = this.querySelector('#checkbox-all');
            const rowChecks = () => Array.from(tbody.querySelectorAll('.row-check'));

            const syncMaster = () => {
                const rows = rowChecks();
                const checked = rows.filter(cb => cb.checked).length;
                checkboxAll.indeterminate = checked > 0 && checked < rows.length;
                checkboxAll.checked = checked === rows.length && rows.length > 0;
                rows.forEach(cb => {
                    const tr = cb.closest('tr');
                    const idx = Number(tr.dataset.rowIndex);
                    this._data[idx].checked = cb.checked;
                });
                this.dispatchEvent(new CustomEvent('selectionchange', {
                    bubbles: true,
                    detail: {
                        selected: this.getSelected().map(x => x[this._rowKey]),
                        count: this.getSelected().length,
                        all: checkboxAll.checked,
                        indeterminate: checkboxAll.indeterminate
                    }
                }));
            };

            checkboxAll?.addEventListener('change', () => {
                rowChecks().forEach(cb => { cb.checked = checkboxAll.checked; });
                syncMaster();
            });

            rowChecks().forEach(cb => {
                cb.addEventListener('change', () => { syncMaster(); });
            });

            // init state
            (() => {
                const rows = rowChecks();
                const checked = rows.filter(cb => cb.checked).length;
                checkboxAll.indeterminate = checked > 0 && checked < rows.length;
                checkboxAll.checked = checked === rows.length && rows.length > 0;
            })();
        }
    }

    // Public API
    getSelected() {
        return this._data.filter(r => !!r.checked);
    }

    // Utils
    _escape(v) {
        if (v === null || v === undefined) return '';
        return String(v).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
    }
}

customElements.define('fb-table', FBTable);
